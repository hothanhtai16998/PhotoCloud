import { useRef } from 'react';
import type { SlideData } from '@/stores/useSliderStore';

export type SliderPreviewMode = 'fixed' | 'thumbnails' | 'strip' | 'wipe';

export function FixedSlideStage({slides, current, mode, collapsed, direction, select, zoom}: {
  slides: SlideData[]; current: number; mode: SliderPreviewMode; collapsed: boolean;
  direction: number; select: (index: number, direction?: number) => void; zoom: (button: HTMLButtonElement) => void;
}) {
  const pointer = useRef<{x: number; id: number} | null>(null);
  const dragged = useRef(false);
  const previous = (current - 1 + slides.length) % slides.length;
  const next = (current + 1) % slides.length;
  const thumbnail = (index: number, side?: string) => <button key={slides[index].id}
    className={`preview-thumbnail ${side || ''}`} type="button" aria-label={`Xem ảnh ${index + 1}: ${slides[index].title}`}
    aria-pressed={index === current} onClick={() => select(index)}>
    <img src={slides[index].image} alt={slides[index].title} draggable={false} />
  </button>;
  return <div className={`fixed-stage ${mode === 'wipe' ? 'stage-wipe' : 'stage-fade'}${direction < 0 ? ' direction-back' : ''}`}>
    <div className="fixed-stage-row">
      {mode === 'fixed' && !collapsed && slides.length > 1 && thumbnail(previous, 'side-preview')}
      <button type="button" className="travel-card fixed-stage-main" aria-label={`Phóng to ảnh: ${slides[current].title}`}
        onPointerDown={event => {pointer.current = {x: event.clientX, id: event.pointerId}; dragged.current = false;}}
        onPointerUp={event => {
          if (pointer.current?.id !== event.pointerId) return;
          const delta = event.clientX - pointer.current.x;
          pointer.current = null;
          if (Math.abs(delta) > 45) {dragged.current = true; select(delta > 0 ? previous : next, delta > 0 ? -1 : 1);}
        }}
        onPointerCancel={() => {pointer.current = null;}}
        onClick={event => {if (!dragged.current) zoom(event.currentTarget); dragged.current = false;}}>
        {slides.map((slide, index) => <span key={slide.id} aria-hidden={index !== current}
          className={`fixed-stage-layer${index === current ? ' is-current' : ''}`}>
          <img className="slide-image" src={slide.image} alt={slide.title} draggable={false} loading="eager" decoding="async" />
          <span className="travel-caption"><strong>{slide.title}</strong><span>{slide.author ? `Ảnh của ${slide.author}` : 'Bộ sưu tập ảnh nổi bật'}</span></span>
        </span>)}
      </button>
      {mode === 'fixed' && !collapsed && slides.length > 2 && thumbnail(next, 'side-preview')}
    </div>
    {mode === 'thumbnails' && !collapsed && <div className="preview-thumbnail-rail" aria-label="Chọn ảnh nổi bật">
      {slides.map((_, index) => thumbnail(index))}
    </div>}
  </div>;
}
