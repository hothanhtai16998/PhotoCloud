import { forwardRef } from 'react';

function CategoryArtwork({name}: {name: string}) {
  const category = name.toLocaleLowerCase('vi');
  const landscape = category.includes('cảnh') || category.includes('trời');
  const architecture = category.includes('kiến');
  const food = category.includes('ẩm');
  const fashion = category.includes('trang');
  const portrait = category.includes('chân');
  const grapes = category.includes('nho');
  const pet = category.includes('thú');
  return <svg viewBox="0 0 120 110" className="globe-artwork" aria-hidden="true">
    <ellipse cx="60" cy="101" rx="51" ry="5" fill="#21484c" opacity=".18" />
    {landscape ? <>
      <circle cx="89" cy="28" r="15" fill="#ffdb68" />
      <path d="M4 97 42 29 78 97Z" fill="#308b93" /><path d="m42 29-12 22 12-5 11 7Z" fill="#ecffff" />
      <path d="m40 97 42-56 35 56Z" fill="#55b691" /><path d="m82 41-13 18 13-4 10 7Z" fill="#e9ffff" />
      <path d="M12 97h97" stroke="#165d69" strokeWidth="5" />
      <path d="m12 76 10-26 10 26Z" fill="#286e4d" /><path d="M22 74v25" stroke="#a55c38" strokeWidth="5" />
    </> : architecture ? <>
      <path d="M10 96V44h27v52M43 96V21h33v75M83 96V36h25v60" fill="#eda960" stroke="#a25b4a" strokeWidth="3" />
      <path d="m43 21 17-15 16 15" fill="#d67b54" />
      {[21,53,66,94].map(x=><path key={x} d={`M${x} 46v8m0 10v8m0 10v8`} stroke="#735777" strokeWidth="6" />)}
      <path d="M58 96V80h10v16" fill="#705268" />
    </> : food ? <>
      <path d="M15 67h91c-3 26-21 33-45 33S20 91 15 67" fill="#ef985e" /><path d="M19 72h83" stroke="#ffe8bd" strokeWidth="6" />
      <path d="M25 64c-8-22 14-29 20-17 8-23 24-22 31-4 16-10 24 0 20 21" fill="#80bb64" />
      <circle cx="45" cy="62" r="12" fill="#e86356" /><circle cx="76" cy="58" r="11" fill="#f9d25f" />
      <path d="m82 10-15 53m27-48L79 65" stroke="#805c43" strokeWidth="5" strokeLinecap="round" />
    </> : fashion ? <>
      <path d="m29 33 18-12h27l19 12 20 30-24 13-12-21v45H42V55L30 76 7 64Z" fill="#ec8d9f" />
      <path d="M47 21c0 17 27 17 27 0" fill="#fbe2c1" /><path d="M58 37v61" stroke="#cc6584" strokeWidth="3" />
      <path d="M67 73h40l5 28H61Z" fill="#7661a9" /><path d="M75 76V65c0-14 23-14 23 0v11" fill="none" stroke="#493777" strokeWidth="5" />
    </> : portrait ? <>
      <path d="M13 100c0-31 26-40 47-40s47 9 47 40" fill="#efb46e" />
      <ellipse cx="60" cy="41" rx="26" ry="31" fill="#f9d5b0" />
      <path d="M33 42V25C33-3 94 0 87 33l-11-3-5-15c-7 11-22 13-38 13" fill="#79564e" />
      <path d="M47 44h3m20 0h3" stroke="#6c4542" strokeWidth="4" strokeLinecap="round" /><path d="M51 56q9 8 18 0" stroke="#c7796a" strokeWidth="3" fill="none" />
      <path d="M35 100V76m50 24V76" stroke="#d38b58" strokeWidth="4" />
    </> : grapes ? <>
      <path d="M59 26c-5-18 9-23 17-18" fill="none" stroke="#815c3f" strokeWidth="5" /><path d="M64 22c24-31 43-8 42 3-20 7-30 7-42-3" fill="#72b867" />
      {[[41,38],[65,38],[88,39],[29,59],[53,60],[77,62],[43,82],[68,84],[56,101]].map(([cx,cy])=><g key={`${cx}-${cy}`}><circle cx={cx} cy={cy} r="13" fill="#8860b1" stroke="#674195" strokeWidth="2" /><circle cx={cx-4} cy={cy-5} r="3" fill="#c9a0de" /></g>)}
    </> : pet ? <>
      <path d="m29 36-5-27 30 19m18 0L97 9l-3 30" fill="#e9aa73" stroke="#ac7759" strokeWidth="3" />
      <ellipse cx="61" cy="69" rx="42" ry="34" fill="#e9aa73" /><ellipse cx="61" cy="79" rx="23" ry="17" fill="#ffe4be" />
      <path d="M41 64h5m31 0h5" stroke="#594449" strokeWidth="5" strokeLinecap="round" /><path d="m55 74 7 7 7-7" fill="#bf6b6d" />
      <path d="M61 81v7m-35-9H8m20 8L8 91m86-12h18M93 87l19 4" stroke="#9b6a58" strokeWidth="3" />
    </> : <>
      <path d="m5 62 43-15 16-37 13-4-7 37 33-9 12 7-46 27-8 34-9-1 1-30-28 7Z" fill="#f4f7ff" stroke="#8ba9c6" strokeWidth="2" />
      <path d="m48 47 22-4-1 25-16 3" fill="#72bfdb" /><path d="m13 33 10-2m76 40 12-2M9 92l16-3" stroke="#ffe3a2" strokeWidth="4" strokeLinecap="round" />
    </>}
  </svg>;
}

// Original SVG artwork; the whole ring rotates as one compositor layer.
export const SliderGlobe = forwardRef<HTMLDivElement, {labels: string[]}>(({labels}, ref) => <div className="travel-globe" aria-hidden="true">
  <div className="globe-rotor" ref={ref}>
    <svg className="globe-earth" viewBox="0 0 400 400">
      <defs><clipPath id="photocloud-earth-clip"><circle cx="200" cy="200" r="198" /></clipPath></defs>
      <circle cx="200" cy="200" r="198" fill="#43d8ed" />
      <g clipPath="url(#photocloud-earth-clip)">
        <path d="m0 91 46-32 63 7 31 40-22 20-15 43-33-5-16 34-29-18-22-50Zm113 111 43 15 29 42-23 21-8 51-24 45-17-26 6-42-20-47Zm99-195 68 7 46 41 67 13 31 70-41 11-14-24-35 8-13-30-33 25-43-14-13-28-47-6Zm31 121 51 14 28 44-17 43-17 46-22-7-25-48-27-30Zm81 157 43-7 31 32-8 28-62-7-22-21Z" fill="#63b844" />
        <path d="M107 10c58 82 57 293-6 396m199-406c-58 93-56 299 8 402" fill="none" stroke="#fff" strokeOpacity=".12" strokeWidth="25" />
        <path d="M178 55c-12-18-38-2-31 13-21-7-27 18-9 25h49c24-5 17-31-9-25m161 141c-13-17-38-2-30 14-22-8-28 16-8 24h50c23-7 16-29-12-25" fill="#f2ffff" />
      </g>
    </svg>
    {labels.map((label,index)=><div className="globe-stop" key={index} style={{transform: `rotate(${index * 360 / labels.length}deg)`}}>
      <div className="globe-stop-content"><CategoryArtwork name={label} /><span>{label}</span></div>
    </div>)}
  </div>
</div>);
SliderGlobe.displayName = 'SliderGlobe';
