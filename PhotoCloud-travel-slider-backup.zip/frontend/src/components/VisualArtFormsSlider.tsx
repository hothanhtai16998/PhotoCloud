import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { motion, useReducedMotion } from 'motion/react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { A11y } from 'swiper/modules';
import type { Swiper as SwiperInstance } from 'swiper';
import { useSliderStore } from '@/stores/useSliderStore';
import { sliderLayoutTransition } from '@/utils/sliderLayoutTransition';
import { t } from '@/i18n';
import 'swiper/css';
import './VisualArtFormsSlider.css';

export const VisualArtFormsSlider = memo(function VisualArtFormsSlider({collapsed = false, layoutMode = 'intro'}: {collapsed?: boolean; layoutMode?: string}) {
  const slides = useSliderStore(state => state.slides);
  const loading = useSliderStore(state => state.loading);
  const reducedMotion = useReducedMotion();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [isDesktop, setIsDesktop] = useState(() => window.matchMedia('(min-width: 769px)').matches);
  const swiperRef = useRef<SwiperInstance | null>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const transition = reducedMotion ? {duration: 0} : sliderLayoutTransition;
  const layoutKey = `${collapsed}-${layoutMode}`;
  const active = slides[currentSlide] || slides[0];
  const closeZoom = useCallback(() => setIsZoomed(false), []);

  useEffect(() => {
    const media = window.matchMedia('(min-width: 769px)');
    const resize = () => { setIsDesktop(media.matches); if (!media.matches) setIsZoomed(false); };
    media.addEventListener('change', resize);
    return () => media.removeEventListener('change', resize);
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    const store = useSliderStore.getState();
    if (store.slides.length) store.resetLoading();
    void (store.hasLoaded ? store.checkAndRefreshIfStale(controller.signal) : store.fetchSlides(controller.signal)).catch(() => {});
    const timer = setInterval(() => {
      if (document.visibilityState === 'visible') void useSliderStore.getState().checkAndRefreshIfStale(controller.signal).catch(() => {});
    }, 5 * 60 * 1000);
    return () => {controller.abort(); clearInterval(timer);};
  }, []);
  useEffect(() => {
    if (!isZoomed) return;
    const overflow = document.body.style.overflow;
    const trigger = triggerRef.current;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus({preventScroll: true});
    return () => {document.body.style.overflow = overflow; if (trigger?.getClientRects().length) trigger.focus({preventScroll: true});};
  }, [isZoomed]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (isZoomed) { if (event.key === 'Escape') closeZoom(); return; }
      if (event.defaultPrevented || event.target instanceof HTMLElement && event.target.closest('input,textarea,select,[contenteditable="true"],[role="dialog"]')) return;
      const rect = sliderRef.current?.getBoundingClientRect();
      if (!rect?.height || rect.bottom <= 0 || rect.top >= window.innerHeight) return;
      if (event.key === 'ArrowLeft') {event.preventDefault(); swiperRef.current?.slidePrev();}
      if (event.key === 'ArrowRight') {event.preventDefault(); swiperRef.current?.slideNext();}
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isZoomed, closeZoom]);

  if (!isDesktop) return null;
  return <motion.div ref={sliderRef} layout layoutDependency={layoutKey} initial={false} transition={transition}
    className={`visual-art-slider travel-slider${collapsed ? ' visual-art-slider-collapsed' : ''}`} style={{originX: 0, originY: 0}}>
    <div className="travel-heading"><span>PHOTOCLOUD</span><h2>Những góc nhìn đáng khám phá</h2></div>
    {slides.length ? <Swiper modules={[A11y]} initialSlide={currentSlide} centeredSlides slidesPerView="auto" spaceBetween={32}
      loop={slides.length >= 3} rewind={slides.length < 3} speed={reducedMotion ? 0 : 650}
      grabCursor resizeObserver watchSlidesProgress lazyPreloadPrevNext={1}
      onSwiper={swiper => {swiperRef.current = swiper;}}
      onSlideChange={swiper => setCurrentSlide(swiper.realIndex)}
      className="travel-swiper" aria-label="Ảnh nổi bật">
      {slides.map((slide, index) => <SwiperSlide key={slide.id}>
        {({isActive, isPrev, isNext}) => <button type="button" className="travel-card"
          tabIndex={isActive ? 0 : -1} aria-label={`Phóng to ảnh: ${slide.title}`}
          onClick={event => {
            if (!swiperRef.current?.allowClick) return;
            if (!isActive) {swiperRef.current?.slideToLoop(index); return;}
            triggerRef.current = event.currentTarget; setIsZoomed(true);
          }}>
          {(isActive || isPrev || isNext) && <img src={slide.image} alt={slide.title} draggable={false}
            className={`slide-image${isActive ? ' slide-image-current' : ''}`} loading={isActive ? 'eager' : 'lazy'} decoding="async" />}
          <div className="travel-caption"><strong>{slide.title}</strong><span>{slide.author ? `Ảnh của ${slide.author}` : 'Bộ sưu tập ảnh nổi bật'}</span></div>
        </button>}
      </SwiperSlide>)}
    </Swiper> : <div className="travel-empty">{loading ? 'Đang tải ảnh…' : t('visualArtSlider.noSlides')}</div>}
    <div className="travel-controls">
      <button type="button" disabled={slides.length < 2} aria-label={t('visualArtSlider.previousSlide')} onClick={() => swiperRef.current?.slidePrev()}>←</button>
      <span aria-live="polite" aria-label={`Ảnh ${currentSlide + 1} trên ${slides.length}`}>{String(currentSlide + 1).padStart(2, '0')} <i>/ {String(slides.length).padStart(2, '0')}</i></span>
      <button type="button" disabled={slides.length < 2} aria-label={t('visualArtSlider.nextSlide')} onClick={() => swiperRef.current?.slideNext()}>→</button>
    </div>
    {isZoomed && active && createPortal(<div className="zoom-overlay" role="dialog" aria-modal="true" aria-label={`Ảnh phóng to: ${active.title}`}
      onClick={event => {if (event.target === event.currentTarget) closeZoom();}}
      onKeyDown={event => {
        if (event.key !== 'Tab') return;
        const buttons = Array.from(event.currentTarget.querySelectorAll('button'));
        if (event.shiftKey && document.activeElement === buttons[0]) {event.preventDefault(); buttons[buttons.length - 1]?.focus();}
        else if (!event.shiftKey && document.activeElement === buttons[buttons.length - 1]) {event.preventDefault(); buttons[0]?.focus();}
      }}>
      <button ref={closeRef} className="slider-zoom-close" aria-label="Đóng ảnh phóng to" onClick={closeZoom}>×</button>
      <button className="slider-zoom-image-button" aria-label="Thu nhỏ ảnh" onClick={closeZoom}><img className="zoom-image" src={active.fullImage || active.image} alt={active.title} /></button>
    </div>, document.body)}
  </motion.div>;
});
